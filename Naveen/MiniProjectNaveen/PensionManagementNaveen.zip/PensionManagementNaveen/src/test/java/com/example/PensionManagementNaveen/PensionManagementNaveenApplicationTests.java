package com.example.PensionManagementNaveen;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PensionManagementNaveenApplicationTests {

	@Test
	void contextLoads() {
	}

}
