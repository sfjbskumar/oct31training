package com.example.PensionManagementKomali;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PensionManagementKomaliApplicationTests {

	@Test
	void contextLoads() {
	}

}
