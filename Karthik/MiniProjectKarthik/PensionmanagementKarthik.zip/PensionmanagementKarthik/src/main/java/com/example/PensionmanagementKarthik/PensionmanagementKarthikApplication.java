package com.example.PensionmanagementKarthik;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PensionmanagementKarthikApplication {

	public static void main(String[] args) {
		SpringApplication.run(PensionmanagementKarthikApplication.class, args);
	}

}
